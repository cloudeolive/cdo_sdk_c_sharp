var class_c_d_o_1_1_init_progress_changed_event =
[
    [ "InitProgressChangedEvent", "class_c_d_o_1_1_init_progress_changed_event.html#a0427cde1704837f55e1da3ffad36ca0e", null ],
    [ "progress", "class_c_d_o_1_1_init_progress_changed_event.html#a73e7aad4f318d85722ca7a939e6ee373", null ]
];