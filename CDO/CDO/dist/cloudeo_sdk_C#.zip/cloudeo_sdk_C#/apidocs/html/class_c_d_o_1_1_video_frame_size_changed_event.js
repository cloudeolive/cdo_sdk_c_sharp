var class_c_d_o_1_1_video_frame_size_changed_event =
[
    [ "SinkId", "class_c_d_o_1_1_video_frame_size_changed_event.html#a286a2f656b1f60042adc4b44c07bfdce", null ],
    [ "Width", "class_c_d_o_1_1_video_frame_size_changed_event.html#ad808e49c7b03d88ed6c56fa567603d6b", null ],
    [ "Height", "class_c_d_o_1_1_video_frame_size_changed_event.html#aa6de59bb53e268e5e2516c4230326289", null ]
];