var class_c_d_o_1_1_media_stats =
[
    [ "avgJitter", "class_c_d_o_1_1_media_stats.html#a28e40f411c5dc27dc601a41ac77f4102", null ],
    [ "avOffset", "class_c_d_o_1_1_media_stats.html#af1b5fef1b8c2fbdb7fe840d199d4a78f", null ],
    [ "bitRate", "class_c_d_o_1_1_media_stats.html#aa34bf3636f655e4e16c892eda4741664", null ],
    [ "cpu", "class_c_d_o_1_1_media_stats.html#aaa4e207f9760a918799116d03b6cf5cf", null ],
    [ "fps", "class_c_d_o_1_1_media_stats.html#a14beb15b52ca011bda197a679dae304d", null ],
    [ "jbLength", "class_c_d_o_1_1_media_stats.html#a0b457b7159285f635701aa53cd4aaf62", null ],
    [ "layer", "class_c_d_o_1_1_media_stats.html#ac01edec8055d54b3a19095434f38da2f", null ],
    [ "loss", "class_c_d_o_1_1_media_stats.html#adf7e3c053b49122b1608f3c15fbacbe3", null ],
    [ "maxJitter", "class_c_d_o_1_1_media_stats.html#adf312884572729737d820ef1df73e74a", null ],
    [ "psnr", "class_c_d_o_1_1_media_stats.html#a70b8de90456c40bf98a4c5400bd5ef4e", null ],
    [ "quality", "class_c_d_o_1_1_media_stats.html#a1a1fd5b3ab94a9465dfbaee9d10d7f73", null ],
    [ "queueDelay", "class_c_d_o_1_1_media_stats.html#a87335510343212928f06050cb4ce82b7", null ],
    [ "rtt", "class_c_d_o_1_1_media_stats.html#a1df67979cc785777ec81df2f5348ab77", null ],
    [ "totalCpu", "class_c_d_o_1_1_media_stats.html#a507fc4f73ae366f35b9e2e270538a5f6", null ],
    [ "totalLoss", "class_c_d_o_1_1_media_stats.html#a652fabcd5e6fec4756fa45679135feff", null ]
];