var searchData=
[
  ['getaudiocapturedevice',['getAudioCaptureDevice',['../interface_c_d_o_1_1_cloudeo_service.html#a1ca13b43bba68328347ca2bc2a423c46',1,'CDO::CloudeoService']]],
  ['getaudiocapturedevicenames',['getAudioCaptureDeviceNames',['../interface_c_d_o_1_1_cloudeo_service.html#a7bca141d77b088c9fc998690bfbd5d84',1,'CDO::CloudeoService']]],
  ['getaudiooutputdevice',['getAudioOutputDevice',['../interface_c_d_o_1_1_cloudeo_service.html#a436fe2c599119bb753f4c4ae50dec0d5',1,'CDO::CloudeoService']]],
  ['getaudiooutputdevicenames',['getAudioOutputDeviceNames',['../interface_c_d_o_1_1_cloudeo_service.html#af46bc596960fff30e5d8251e58851358',1,'CDO::CloudeoService']]],
  ['getscreencapturesources',['getScreenCaptureSources',['../interface_c_d_o_1_1_cloudeo_service.html#ab3637525b30442938cdfdc44e62edfc7',1,'CDO::CloudeoService']]],
  ['getservice',['getService',['../class_c_d_o_1_1_platform.html#a7f7daded175e4c1ea83283e8c57ed9a2',1,'CDO::Platform']]],
  ['getspeakersvolume',['getSpeakersVolume',['../interface_c_d_o_1_1_cloudeo_service.html#ac6eb3145ea7d223e34bb3e51295b981a',1,'CDO::CloudeoService']]],
  ['getversion',['getVersion',['../interface_c_d_o_1_1_cloudeo_service.html#af9c24aba76e2c6c425b4f9d9ab3edb78',1,'CDO::CloudeoService']]],
  ['getvideocapturedevice',['getVideoCaptureDevice',['../interface_c_d_o_1_1_cloudeo_service.html#aa0a58bb8919e9e8be5c699bdc989c217',1,'CDO::CloudeoService']]],
  ['getvideocapturedevicenames',['getVideoCaptureDeviceNames',['../interface_c_d_o_1_1_cloudeo_service.html#a25fa5804b1a059dc6605c6a329552655',1,'CDO::CloudeoService']]]
];
