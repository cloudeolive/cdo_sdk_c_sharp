var searchData=
[
  ['sendmessage',['sendMessage',['../interface_c_d_o_1_1_cloudeo_service.html#a5189f9b699f06c6ad010eeb737dd1b31',1,'CDO::CloudeoService']]],
  ['setapplicationid',['setApplicationId',['../interface_c_d_o_1_1_cloudeo_service.html#a44fdcf4895a24abfa398e7f6bbc5f362',1,'CDO::CloudeoService']]],
  ['setaudiocapturedevice',['setAudioCaptureDevice',['../interface_c_d_o_1_1_cloudeo_service.html#aef6e4f9d5f48c7ff8991319fe335f22a',1,'CDO::CloudeoService']]],
  ['setaudiooutputdevice',['setAudioOutputDevice',['../interface_c_d_o_1_1_cloudeo_service.html#ad1a5724522cdcad09334ceb4530b495d',1,'CDO::CloudeoService']]],
  ['setspeakersvolume',['setSpeakersVolume',['../interface_c_d_o_1_1_cloudeo_service.html#a723fad1adc32cce991cad0f76cde6bd3',1,'CDO::CloudeoService']]],
  ['setvideocapturedevice',['setVideoCaptureDevice',['../interface_c_d_o_1_1_cloudeo_service.html#a350c6e6f57c286f8224e37f766f78a8b',1,'CDO::CloudeoService']]],
  ['shutdown',['shutdown',['../class_c_d_o_1_1_render_support.html#a56ba4e8e4c83b7ea66470cc19dd20669',1,'CDO::RenderSupport']]],
  ['startlocalvideo',['startLocalVideo',['../interface_c_d_o_1_1_cloudeo_service.html#a0eac505f4ece0b409bad18726b401101',1,'CDO::CloudeoService']]],
  ['startmeasuringstatistics',['startMeasuringStatistics',['../interface_c_d_o_1_1_cloudeo_service.html#aa1f619f46260733f900536b2ba7be46b',1,'CDO::CloudeoService']]],
  ['startplayingtestsound',['startPlayingTestSound',['../interface_c_d_o_1_1_cloudeo_service.html#a2f22324eb2df71b27a7e35978af7ed64',1,'CDO::CloudeoService']]],
  ['statechangedeventhandler',['StateChangedEventHandler',['../class_c_d_o_1_1_platform_init_listener_dispatcher.html#aa197511d7b672c6cebeae613fbeedc92',1,'CDO::PlatformInitListenerDispatcher']]],
  ['stop',['stop',['../class_c_d_o_1_1_rendering_widget.html#abe7b2d2f2e63fd78e2f44b8e6dd5f35b',1,'CDO::RenderingWidget']]],
  ['stoplocalvideo',['stopLocalVideo',['../interface_c_d_o_1_1_cloudeo_service.html#a42c5895e0f3621ed949d84133a10ab3f',1,'CDO::CloudeoService']]],
  ['stopmeasuringstatistics',['stopMeasuringStatistics',['../interface_c_d_o_1_1_cloudeo_service.html#ad7ed6ec8bd78522a7f48773343e9ecd1',1,'CDO::CloudeoService']]],
  ['stopplayingtestsound',['stopPlayingTestSound',['../interface_c_d_o_1_1_cloudeo_service.html#ae9034991ebcb366ca57d1d86ce810112',1,'CDO::CloudeoService']]]
];
