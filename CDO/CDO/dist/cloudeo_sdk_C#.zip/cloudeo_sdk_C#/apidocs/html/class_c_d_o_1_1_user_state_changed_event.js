var class_c_d_o_1_1_user_state_changed_event =
[
    [ "ScopeId", "class_c_d_o_1_1_user_state_changed_event.html#a8dc9e45647c287556e310762fa76f0c2", null ],
    [ "MediaType", "class_c_d_o_1_1_user_state_changed_event.html#ab46af7f9ee386b6321b636f2d04e6739", null ],
    [ "IsConnected", "class_c_d_o_1_1_user_state_changed_event.html#a4d799f1b3f0c28055aede1b80aac40ba", null ],
    [ "UserId", "class_c_d_o_1_1_user_state_changed_event.html#aeea36457fe9394e69b11e0b047477040", null ],
    [ "AudioPublished", "class_c_d_o_1_1_user_state_changed_event.html#ae0b4821b92322b0fd5825e58cdaf5304", null ],
    [ "ScreenPublished", "class_c_d_o_1_1_user_state_changed_event.html#ac0d071699ad565c5a399be3277802975", null ],
    [ "ScreenSinkId", "class_c_d_o_1_1_user_state_changed_event.html#a7245bc9b3f63e689ed0a3ffbf3eaf610", null ],
    [ "VideoPublished", "class_c_d_o_1_1_user_state_changed_event.html#a7fec6c21d58c43de758f75f408e82733", null ],
    [ "VideoSinkId", "class_c_d_o_1_1_user_state_changed_event.html#ac69d828390bcc1db481b4623c4450ef6", null ]
];