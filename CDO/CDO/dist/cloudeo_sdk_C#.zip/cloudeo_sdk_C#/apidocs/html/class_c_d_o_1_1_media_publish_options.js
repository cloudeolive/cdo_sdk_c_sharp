var class_c_d_o_1_1_media_publish_options =
[
    [ "windowId", "class_c_d_o_1_1_media_publish_options.html#ae6f641bc2c8ca73b4d6243fbe6e0fa54", null ],
    [ "nativeWidth", "class_c_d_o_1_1_media_publish_options.html#ad90fd3a9b509837027f63fd4a07a8ac3", null ]
];