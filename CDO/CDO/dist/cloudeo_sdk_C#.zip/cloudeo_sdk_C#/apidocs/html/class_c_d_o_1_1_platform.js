var class_c_d_o_1_1_platform =
[
    [ "init", "class_c_d_o_1_1_platform.html#aaa2799ed1b27a662488962d36dd25f0c", null ],
    [ "init", "class_c_d_o_1_1_platform.html#a954ed3b9e4d6d3568bf9b63152ac15c5", null ],
    [ "release", "class_c_d_o_1_1_platform.html#a1df23be67ab173e7a814da5258631bbd", null ],
    [ "getService", "class_c_d_o_1_1_platform.html#a7f7daded175e4c1ea83283e8c57ed9a2", null ],
    [ "renderSink", "class_c_d_o_1_1_platform.html#aed80bf442c6020ae34f07e17db9eba68", null ],
    [ "createResponder< T >", "class_c_d_o_1_1_platform.html#ab1ae3c8865b93156a7bb1496df33fc81", null ],
    [ "R< T >", "class_c_d_o_1_1_platform.html#a100229f157ca2a0a75200f459bf0b694", null ],
    [ "Service", "class_c_d_o_1_1_platform.html#a7a11865185d29079143eefac20a01236", null ],
    [ "AssemblyDirectory", "class_c_d_o_1_1_platform.html#a7753a1acdcf738715952a46354290daa", null ]
];