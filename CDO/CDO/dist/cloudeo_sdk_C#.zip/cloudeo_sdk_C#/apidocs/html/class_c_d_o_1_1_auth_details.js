var class_c_d_o_1_1_auth_details =
[
    [ "expires", "class_c_d_o_1_1_auth_details.html#ab712942f1fc45cd26be3c2ae41040734", null ],
    [ "userId", "class_c_d_o_1_1_auth_details.html#aba6587f3b8ad4bcf2d4fb8a143c375da", null ],
    [ "salt", "class_c_d_o_1_1_auth_details.html#a6f9e6ecff92f9b9c5d157be284b58239", null ],
    [ "signature", "class_c_d_o_1_1_auth_details.html#af766843bb3efe618b3733d10fa230579", null ]
];