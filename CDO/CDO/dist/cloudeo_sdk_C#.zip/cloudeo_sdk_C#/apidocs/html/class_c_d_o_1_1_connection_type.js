var class_c_d_o_1_1_connection_type =
[
    [ "NOT_CONNECTED", "class_c_d_o_1_1_connection_type.html#afd82e58186905ff577f141d987a3a389", null ],
    [ "UDP_RELAY", "class_c_d_o_1_1_connection_type.html#a9c9196ad9061526c83b0d2bcbc89795f", null ],
    [ "UDP_P2P", "class_c_d_o_1_1_connection_type.html#ae7c5f11e8d00cf6caecac3f025d52716", null ],
    [ "TCP_RELAY", "class_c_d_o_1_1_connection_type.html#affbabcbec3580373287b8703793894dd", null ],
    [ "StringValue", "class_c_d_o_1_1_connection_type.html#a9a520c2d19b41672391d33b7b4eb7dc5", null ]
];