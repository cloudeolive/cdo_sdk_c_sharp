var class_c_d_o_1_1_media_stats_event =
[
    [ "ScopeId", "class_c_d_o_1_1_media_stats_event.html#a12c58649bd9aaa2b4698f5d973d23aab", null ],
    [ "MediaType", "class_c_d_o_1_1_media_stats_event.html#ab35205969f6f7d139cae0d91258045b5", null ],
    [ "RemoteUserId", "class_c_d_o_1_1_media_stats_event.html#a127d5f88b5ff1dc667d0571ca10a50ba", null ],
    [ "Stats", "class_c_d_o_1_1_media_stats_event.html#a2f446086a06fb010ae5731de5de37ae8", null ]
];