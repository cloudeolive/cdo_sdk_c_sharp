var class_c_d_o_1_1_platform_init_options =
[
    [ "sdkPath", "class_c_d_o_1_1_platform_init_options.html#a06f5ac2b26217e6247f6b66c3046a81f", null ]
];