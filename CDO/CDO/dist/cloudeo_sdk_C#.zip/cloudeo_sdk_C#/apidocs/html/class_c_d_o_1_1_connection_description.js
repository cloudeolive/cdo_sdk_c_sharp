var class_c_d_o_1_1_connection_description =
[
    [ "ConnectionDescription", "class_c_d_o_1_1_connection_description.html#a6df258a96c88ec0326a0cc4ea03f75e2", null ],
    [ "highVideoStream", "class_c_d_o_1_1_connection_description.html#a6de2d960b125602519e95cd86538b267", null ],
    [ "lowVideoStream", "class_c_d_o_1_1_connection_description.html#a5097a2391f4282469889b7c83ca81d80", null ],
    [ "authDetails", "class_c_d_o_1_1_connection_description.html#a9c6a9bf000c788020c1c05a6ec319263", null ],
    [ "autopublishVideo", "class_c_d_o_1_1_connection_description.html#a4f631308ecd6395b6d820a7018443d91", null ],
    [ "autopublishAudio", "class_c_d_o_1_1_connection_description.html#a54b6c418b363952fd1a9eb982bd59ca6", null ],
    [ "url", "class_c_d_o_1_1_connection_description.html#ab3a1ac5db6676fb0effe41bd6bcc1422", null ],
    [ "scopeId", "class_c_d_o_1_1_connection_description.html#af0162802d892a2691796b819498906d3", null ],
    [ "token", "class_c_d_o_1_1_connection_description.html#aadc3e622063c720398e77215123d626d", null ]
];