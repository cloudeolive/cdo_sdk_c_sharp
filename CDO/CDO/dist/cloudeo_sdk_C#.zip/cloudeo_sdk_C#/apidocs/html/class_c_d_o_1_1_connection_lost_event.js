var class_c_d_o_1_1_connection_lost_event =
[
    [ "ScopeId", "class_c_d_o_1_1_connection_lost_event.html#a74e8163215fc51dab003884d89be819e", null ],
    [ "ErrCode", "class_c_d_o_1_1_connection_lost_event.html#ad2e92a4cecc240c301e7b8e941810f50", null ],
    [ "ErrMessage", "class_c_d_o_1_1_connection_lost_event.html#a57e51d6ae282b1b7840e9b0e3ccd8c8d", null ]
];