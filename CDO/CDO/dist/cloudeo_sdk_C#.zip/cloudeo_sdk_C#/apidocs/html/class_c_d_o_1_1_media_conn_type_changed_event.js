var class_c_d_o_1_1_media_conn_type_changed_event =
[
    [ "ScopeId", "class_c_d_o_1_1_media_conn_type_changed_event.html#a38394ccf7666c62a7bd7ef341cbea90c", null ],
    [ "MediaType", "class_c_d_o_1_1_media_conn_type_changed_event.html#aea4fccb344e7f73f8b43b262b2dc900f", null ],
    [ "ConnType", "class_c_d_o_1_1_media_conn_type_changed_event.html#a82d2987e04b439cba716ee48ce4ea869", null ]
];