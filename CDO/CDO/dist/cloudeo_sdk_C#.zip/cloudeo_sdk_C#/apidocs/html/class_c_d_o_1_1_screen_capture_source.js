var class_c_d_o_1_1_screen_capture_source =
[
    [ "id", "class_c_d_o_1_1_screen_capture_source.html#a7acf6812739f8ebd96c03b8a0b620c19", null ],
    [ "title", "class_c_d_o_1_1_screen_capture_source.html#a6af9df6490372624db6e4497e6b36345", null ],
    [ "snapshot", "class_c_d_o_1_1_screen_capture_source.html#a465a722a39ac77c214b053a1bd6bece3", null ]
];