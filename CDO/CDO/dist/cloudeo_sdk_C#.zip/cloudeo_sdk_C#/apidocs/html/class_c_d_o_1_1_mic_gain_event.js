var class_c_d_o_1_1_mic_gain_event =
[
    [ "Gain", "class_c_d_o_1_1_mic_gain_event.html#aebd22eb0c11794216084383c0c45ba89", null ]
];