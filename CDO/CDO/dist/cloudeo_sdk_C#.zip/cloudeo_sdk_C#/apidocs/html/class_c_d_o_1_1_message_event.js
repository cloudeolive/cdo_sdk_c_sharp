var class_c_d_o_1_1_message_event =
[
    [ "SrcUserId", "class_c_d_o_1_1_message_event.html#a1cd5a8d1b86d3bdcf7612ac9ef3771e7", null ],
    [ "Data", "class_c_d_o_1_1_message_event.html#abd6ac07bf809100a7975e069018302a1", null ]
];