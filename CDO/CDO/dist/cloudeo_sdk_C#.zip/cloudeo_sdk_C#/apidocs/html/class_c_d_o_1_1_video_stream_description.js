var class_c_d_o_1_1_video_stream_description =
[
    [ "maxWidth", "class_c_d_o_1_1_video_stream_description.html#a909caf280a753f540d53dab93012e07d", null ],
    [ "maxHeight", "class_c_d_o_1_1_video_stream_description.html#acb5046ba0e422ecc301fd19d9bc49695", null ],
    [ "maxBitRate", "class_c_d_o_1_1_video_stream_description.html#a4c6efcf2830d881a43368e3eadd81e2a", null ],
    [ "maxFps", "class_c_d_o_1_1_video_stream_description.html#a5709eb8880463cff617aebab9e95408c", null ],
    [ "publish", "class_c_d_o_1_1_video_stream_description.html#a34e4623faf540948fe27752c43dfc8f2", null ],
    [ "receive", "class_c_d_o_1_1_video_stream_description.html#a0576db80f4db4ec888768c7e73caad86", null ]
];