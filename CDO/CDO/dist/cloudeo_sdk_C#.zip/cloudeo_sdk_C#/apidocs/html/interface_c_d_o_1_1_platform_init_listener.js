var interface_c_d_o_1_1_platform_init_listener =
[
    [ "onInitProgressChanged", "interface_c_d_o_1_1_platform_init_listener.html#a95d0b6374f414b98823b8e03670bf10a", null ],
    [ "onInitStateChanged", "interface_c_d_o_1_1_platform_init_listener.html#a35800fbc10f1a168d3217479d27fda74", null ]
];