var class_c_d_o_1_1_init_state_changed_event =
[
    [ "InitState", "class_c_d_o_1_1_init_state_changed_event.html#ae9f4494939ec25ac9937d4d6042e74cf", [
      [ "INITIALIZED", "class_c_d_o_1_1_init_state_changed_event.html#ae9f4494939ec25ac9937d4d6042e74cf", null ],
      [ "ERROR", "class_c_d_o_1_1_init_state_changed_event.html#ae9f4494939ec25ac9937d4d6042e74cf", null ]
    ] ],
    [ "state", "class_c_d_o_1_1_init_state_changed_event.html#ab1a66b3a508b05325541852c9219f0d3", null ],
    [ "errCode", "class_c_d_o_1_1_init_state_changed_event.html#a4945fad9e6a36cca765bec57f7ccaa78", null ],
    [ "errMessage", "class_c_d_o_1_1_init_state_changed_event.html#a8bf9482f0eec99dc54552400d1ee7a7b", null ]
];